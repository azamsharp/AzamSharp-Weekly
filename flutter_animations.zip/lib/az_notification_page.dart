
import 'package:flutter/material.dart';
import 'package:flutter_animations/az_notification.dart';

class AZNotificationPage extends StatefulWidget {
  @override 
  _AZNotificationPageState createState() => _AZNotificationPageState(); 
}

class _AZNotificationPageState extends State<AZNotificationPage> {

  bool _isActive = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Stack(children: <Widget>[
        RaisedButton(
          child: Text("Press me"),
          onPressed: () {
            setState(() {
              _isActive = !_isActive;
            });
          },
        ),
        AZNotification(
          isActive: _isActive,
          child: Text("AZNotification",style: TextStyle(fontSize: 22, color: Colors.white)), 
          maxHeight: 100,
          borderRadius: 20,
          status: NotificationStatus.error,
          completion: () {
            setState(() {
              _isActive = false; 
            });
          },
        )
      ]),
    );
  }

}