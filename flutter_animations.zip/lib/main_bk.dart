/*

import 'package:flutter/material.dart';
import 'package:sprung/next.dart';

void main() => runApp(App());

class App extends StatefulWidget {
  @override 
  _AppState createState() => _AppState(); 
}

class _AppState extends State<App> {

  final _movies = ["Spiderman","Superman","Batman","Flash","Ironman","Captain", "America"];
  final _colors = [Colors.orange, Colors.blue, Colors.purple, Colors.pink, Colors.green, Colors.brown, Colors.teal];
  final _heights = List<double>.generate(10, (i) => 50);

  int _lastIndex = 0; 
  //bool _selected = false; 

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Flutter Animations",
      home: Scaffold(
        appBar: AppBar(
          title: Text("Flutter Animations")
        ),
        body: ListView.builder(
          itemCount: _movies.length,
          itemBuilder: (context, index) {

            bool _selected = false; 

            return ListTile(
              onTap: () {

                if(_lastIndex != index) {
                  _heights[_lastIndex] = 50; 
                  _lastIndex = index; 
                }
                print(_heights);

                setState(() {
                  _heights[index] = 200; 
                }); 

              },
              title: Padding(
                padding: const EdgeInsets.all(8.0),
                child: AnimatedContainer(
                  duration: Duration(milliseconds: 750),
                  curve: Sprung(10),
                  height: _heights[index],
                  child: Container(
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: _colors[index],
                      borderRadius: BorderRadius.circular(10)
                    ),
                    child: Text(_movies[index],style: TextStyle(fontSize: 22, color: Colors.white))
                  ),
                ),
              ),
            );
          },
        )
      )
    );
  }
} */