import 'package:flutter/material.dart';
import 'package:flutter_animations/az_notification_page.dart';
import 'package:flutter_animations/samples/sample1.dart';

void main() => runApp(App());

class App extends StatefulWidget {
  @override
  _AppState createState() => _AppState();
}

class _AppState extends State<App> {
  
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: "Flutter Animations",
        home: Scaffold(
            appBar: AppBar(title: Text("Flutter Animations")),
            body: AZNotificationPage()));
  }
}
