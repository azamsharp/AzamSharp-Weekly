

import 'package:flutter/material.dart';

class Sample1 extends StatefulWidget {
  @override 
  _Sample1State createState() => _Sample1State(); 
}

class _Sample1State extends State<Sample1> {

  double _length = 50.0; 
  Color _color = Colors.green; 

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
        AnimatedContainer(
            width: _length, 
            height: _length,
            color: _color, 
            duration: Duration(seconds: 3),
        ), 
        RaisedButton(
          child: Text("Press me"), 
          onPressed: () {
            setState(() {
              _length = 100; 
              _color = Colors.purple; 
            });
          },
        )
      ])
    ); 
  }

}