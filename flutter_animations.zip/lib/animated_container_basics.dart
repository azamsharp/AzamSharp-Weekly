import 'package:flutter/material.dart';

class AnimatedContainerBasics extends StatefulWidget {
  @override
  _AnimatedContainerBasicsState createState() =>
      _AnimatedContainerBasicsState();
}

class _AnimatedContainerBasicsState extends State<AnimatedContainerBasics> {

  double _width = 100; 
  Color _color = Colors.green; 
  double _borderRadius = 0.0; 

  @override
  Widget build(BuildContext context) {
    return Align(
      child: Container(
        child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
             
              Padding(
                padding: EdgeInsets.only(top: MediaQuery.of(context).size.height/4),
                child: RaisedButton(
                  child: Text("Press me!"),
                  onPressed: () {
                    setState(() {
                      _width = 200;
                      _borderRadius = 100;
                      //_color = Colors.purple;
                    });
                  },
                ),
              ),
              Align(
                alignment: Alignment.center,
                child:
                  AnimatedContainer(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(_borderRadius), 
                    color: Colors.green
                  ),
                  width: _width,
                  height: _width,
                  duration: Duration(seconds: 5),
                ),
              ),
            ]),
      ),
    );
  }
}
